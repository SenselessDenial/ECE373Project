package game;

import java.awt.Rectangle;
import java.util.ArrayList;

import game.components.Picture;
import game.util.Interfaces;
import game.util.Vector2;
import gameLogic.GameState;

// A template used for making scenes.
// do NOT inherit from this class. Instead copy the contents and add on to it.
public final class SettingsMenu extends Scene {

	/// add entity declarations and additional things here
	private InteractiveButton volumeUp;
	private InteractiveButton volumeDown;
	private ArrayList<Picture> volumeIndicators;
	
	private InteractiveButton fullscreenButton;
	
	private InteractiveButton backButton;
	
	public SettingsMenu() {
		super();
		// do not touch!
	}
	
	@Override
	public void begin() {
		super.begin();
		Entity mainscreen = new Entity();
		Picture mainscreenimage = new Picture("corkboard.png");
		
		mainscreen.add(mainscreenimage);
		add(mainscreen);
		
		Entity volumeText = new Entity(0, 0);
		Picture volumeTextP = new Picture("timer2.png");
		volumeText.add(volumeTextP);
		volumeUp = new InteractiveButton(new Vector2(300, 100), this, new Texture("resetButton.png"), new Texture("resetButton.png"), Interfaces.VolumeUp);
		volumeDown = new InteractiveButton(new Vector2(0, 100), this, new Texture("startButton.png"), new Texture("startButton.png"), Interfaces.VolumeDown);
		volumeIndicators = new ArrayList<Picture>();
		setVolumeIndicators();
		
		Entity fullscreenText = new Entity(0, 150); 
		Picture fullscreenTextP = new Picture("startButton.png");
		fullscreenText.add(fullscreenTextP);
		fullscreenButton = new InteractiveButton(new Vector2(0, 200), this, new Texture("exitButton.png"), new Texture("exitButton.png"), Interfaces.Fullscreen);
		
		backButton = new InteractiveButton(new Vector2(100, 200), this, new Texture("backbutton.png"), new Texture("backbutton.png"), Interfaces.GoToMainMenu);
		
		add(backButton);
		add(volumeText);
		add(volumeUp);
		add(volumeDown);
		add(fullscreenText);
		add(fullscreenButton);
		this.renderer.camera.setBoundaries(new Rectangle(0, 0, 1280, 0));
        this.renderer.camera.setScale(2.75f);
	}
	
	@Override
	public void update() {
		super.update();
		// super.update() already updates entities. add any additional update here.
		for (int i = 0; i < volumeIndicators.size(); i++) {
			if (i + 1 == GameState.volume) {
				volumeIndicators.get(i).setTexture(new Texture("timer1.png"));
			}
			else {
				volumeIndicators.get(i).setTexture(new Texture("1.png"));
			}
		}
	}
	
	@Override
	public void render() {
		super.render();
		// don't touch unless you specifically need to add something.
	}
	
	private void setVolumeIndicators() {
		for (int i = 0; i < 10; i++) {
			Entity newInd = new Entity(100 + 10 * i, 100);
			if (i == GameState.volume) {
				Picture ind = new Picture("1.png");
				volumeIndicators.add(ind);
				newInd.add(ind);
			}
			else {
				Picture ind = new Picture("timer1.png");
				volumeIndicators.add(ind);
				newInd.add(ind);
			}
			add(newInd);
		}
	}
}
