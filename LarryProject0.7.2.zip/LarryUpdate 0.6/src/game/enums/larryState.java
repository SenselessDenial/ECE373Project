package game.enums;

public enum larryState { AETHER, WINDOW, DOORRIGHT, DOORLEFT, VENT}
