package game;

import game.components.Picture;
import game.util.Interfaces;
import game.util.Vector2;

// A template used for making scenes.
// do NOT inherit from this class. Instead copy the contents and add on to it.
public final class WinScene extends Scene {

	/// add entity declarations and additional things here
	
	public WinScene() {
		super();
		// do not touch!
	}
	
	@Override
	public void begin() {
		super.begin();

		Entity background = new Entity(0, 0);
		Picture bgImage = new Picture("winbg.png");
		background.add(bgImage);
		add(background);
		
		InteractiveButton resetButton = new InteractiveButton(new Vector2(450, 250), this, new Texture("resetButton.png"),
				new Texture("resetButton.png"), Interfaces.GoToMainMenu);

		add(resetButton);
		
		this.renderer.camera.setScale(3);
	}
	
	@Override
	public void update() {
		super.update();
		// super.update() already updates entities. add any additional update here.
	}
	
	@Override
	public void render() {
		super.render();
		// don't touch unless you specifically need to add something.
	}
	
}
