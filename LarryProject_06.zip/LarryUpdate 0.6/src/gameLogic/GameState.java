package gameLogic;

import java.util.ArrayList;

import game.BClip;
import game.Game;
import gameLogic.Ingress;
import game.SceneManager;
import game.enums.larryState;
import game.util.Logger;
import game.util.Vector2;

import java.util.HashMap;

//////////GameState Class Description///////////
/*
 * GameState is a non entity class that holds game logic variables so that they update regardless of
 * what scene the player is currently in. It has an update function that is used in relevant scenes
 * so larry moves around freely during other scenes.
 */

///////// CHANGE LOG //////////

/*
 * 11/10/2021 class created. 
 *
 * 11/13/2021 
 *   added hashmap for solutions
 *   added nightSetup function (incomplete) that sets the puzzle for each night and resets the Ingresses
 */

////////////////////////////////

public class GameState {
	// Game Data 
	public static int nightNumber;
	public static HashMap<Integer, ArrayList<ArrayList<Integer>>> solutions;
	public static Nonogram puzzle;
	public static ClueboardGraph clueboard;
	public static ClueboardGraph clueSolution;
	public static double timer;								//timer determines the length of the night, if the player survives larry 
															//they get the win screen
	// Ingresses
	public static Ingress windowright;
	public static Ingress doorright;
	public static Ingress windowleft;
	public static Ingress doorleft;
	public static Ingress vent;
	
	// Larry Data
	public static int larryGotcha;
	public static larryState larryLocation;
	public static Larry larry;
	private static BClip alertSound = new BClip("mgs.wav");
	private static boolean larryNoticed = false;
	private static boolean alertPlayed = false;
	
	
	
	public GameState() {
		
		
		
	}
	
	public static void initialize() {
		//sets up night 1
		
		GameState.timer = 10000;
		
		GameState.windowleft = new Ingress("windowleft");
		GameState.windowright = new Ingress("windowright");
		GameState.doorleft = new Ingress("doorleft");
		GameState.doorright = new Ingress("doorright");
		GameState.vent = new Ingress("vent");
		
		//TODO, integrate a solution for each night
		//solutions = new HashMap<Integer, ArrayList<ArrayList<Integer>>>();
		//getSolutions();
		Clue clue = new Clue(SceneManager.getCorkboardScene(), "sampleclue.png", 1, "girl");
		Clue gunclue = new Clue(SceneManager.getCorkboardScene(), "sampleclue2.png", new Vector2(1920/4, 0), 2, "gun");
		
		// Delete after integrating multiple nights
		ArrayList<ArrayList<Integer>> solution = new ArrayList<ArrayList<Integer>>();
		//PLACEHOLDER 5x5 PUZZLE (ALL 1's = SOLUTION)
		for (int  i = 0; i < 5; i++) {
			solution.add(new ArrayList<Integer>());
			for (int j = 0; j < 5; j++) {
				solution.get(i).add(1);
			}
		}
		
		larry = new Larry();
		nightNumber = 1;
		
		puzzle = new Nonogram(5, solution);
		larryGotcha = 0;
		
		
		
		ArrayList<ArrayList<Integer>> cSolution = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < 3; i++) {
			cSolution.add(new ArrayList<Integer>());
		}
		cSolution.get(0).add(0);
		cSolution.get(0).add(1);
		cSolution.get(0).add(0);
		cSolution.get(1).add(1);
		cSolution.get(1).add(0);
		cSolution.get(1).add(1);
		cSolution.get(2).add(0);
		cSolution.get(2).add(1);
		
		clueboard = new ClueboardGraph();
		clueSolution = new ClueboardGraph(new ArrayList<Clue>(), cSolution);
		
		GameState.clueboard.addClue(clue);
		GameState.clueboard.addClue(gunclue);
	}
	
	// getSolutions is for when we have multiple solutions to update 
	/*private static void getSolutions() {
		//fills in the solutions hashmap with our set solutions 
		//contained in a text file in the content folder.
		
		ArrayList<ArrayList<Integer>> solution = new ArrayList<ArrayList<Integer>>();
		//PLACEHOLDER 5x5 PUZZLE (ALL 1's = SOLUTION)
		for (int  i = 0; i < 5; i++) {
			solution.add(new ArrayList<Integer>());
			for (int j = 0; j < 5; j++) {
				solution.get(i).add(1);
			}
		}
	}*/
	
	public static void nightSetup() {										//this sets up the nonogram and larry so that each new nigth has a new larry and 	
		GameState.reset();													//a new puzzle
		puzzle = new Nonogram(10, solutions.get(GameState.nightNumber));
		larryLocation = larryState.AETHER;
	}
	
	public static void winner() {											//regardless of scene, if the player wins they are sent to the win screen
		Game.instance.setScene(SceneManager.getScene("win"));
		nightNumber += 1;
		SaveLoad.saveGame();
		reset();
	}
	
	public static void loser() {											//regardless of scene, the player will be sent to the lose screen and all 
		larryGotcha = 1;													//game logic variables will be set to default
		if (nightNumber == 1) {
			clueboard.reset();
			Logger.Log("Reset Clueboard");
		}
		else {
			SaveLoad.loadData();
		}
		
		Game.instance.setScene(SceneManager.getScene("lose"));
		reset();
	}
	
	public static void scoobyDoo() {
		Logger.Log("I would've gotten away with it too if it weren't for you meddling kids.");
		winner();
	}
	
	public static void update() {											//because GameState is not an entity owned by one scene, it needs its own
		larry.update();														//update function that will be called during game logic segments
		timer -= 1.0/60.0;													//timer updates every frame 
		//Logger.Log(timer);
		if(timer < 0) {
			winner();
		}
		
		if ((larryLocation == larryState.WINDOW || larryLocation == larryState.DOORRIGHT) && Game.instance.getScene().equals(SceneManager.getScene("test"))) {
			larryNoticed = true;
		}
		
		if (larryNoticed == true && alertPlayed == false) {
			alertSound.start();
			alertPlayed = true;
		}
		
		if (larryLocation == larryState.AETHER) {
			larryNoticed = false;
			alertPlayed = false;
		}
		
		
	}																		//this way, larry does not move before the game has started
	
	public static void reset() {											//scrubs the gamelogic objects so a fresh game can be played
		windowright.blocked = false;
		doorright.blocked = false;
		windowleft.blocked = false;
		doorleft.blocked = false;
		vent.blocked = false;
		
		larry.location = larryState.AETHER;
		
		larryGotcha = 0;
		timer = 10000;
		
		
		
		puzzle.reset();
		
	}

}
